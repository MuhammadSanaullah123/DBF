import React from 'react'
import styles from './Footer.module.css'

const Footer = () => {
  return (
    <>
      <div className={styles.footermain}>
<div className={styles.footText}>CopyRight @ 2023</div>
      </div>
    </>
  )
}

export default Footer
